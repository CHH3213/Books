%% Copyright (C) 2015 — Pieter Abbeel — All rights reserved.
%% This code was developed for CS 287 Advanced Robotics.  
%% This code is free to be re-used for educational purposes as long as
%% this copyright notice is included.
%% For all other uses, please contact the author at
%% pabbeel@cs.berkeley.edu.

%% double integrator dynamics

dt = 0.1;

A = [1 dt; 0 1];
B = [0; dt];
dynamics = @(x,u) A*x + B*u;

%% LQR cost function with discounting

Q = [1 0; 0 1];
R = 1;
gamma = 0.99;
cost = @(x,u) 0.5*x'*Q*x + 0.5*u'*R*u;

H = 100; % effective horizon we'll be computing with

%% solve the discounted LQR problem
P = eye(2);
for k=1:H % till convergence...
    K = pinv(R + gamma*B'*P*B)*gamma*B'*P*A;
    P = Q + K'*R*K + gamma*(A-B*K)'*P*(A-B*K);
end
policy = @(x) -K*x;

%% now let's simulate from a few starting conditions
q0 = -2:0.2:2;
qdot0 = -2:0.2:2;
[meshgrid_q0, meshgrid_qdot0] = meshgrid(q0,qdot0);

[qsim, usim, vpi] = simulate_policy(dynamics, policy, cost, gamma, meshgrid_q0, meshgrid_qdot0, H);

%% let's plot results:

plot_sim_trajectories_values(meshgrid_q0, meshgrid_qdot0, qsim, usim, vpi, 'plots/exact');

% plot ground-truth values:
figure;
f = @(x,y) x.^2*0.5*P(1,1)+y.^2*0.5*P(2,2)+x.*P(2,1).*y;
ezcontourf(f, [-2,2], 99);
colorbar;

print('-dpng', [], 'plots/exact__closed_form__values');

%% 1. let's just discretize the actions from the optimal policy, and see how much that affects performance:

minu=-3; hu=0.2; maxu=3;

for hu = [0.01 0.1 0.2 0.5 1]
policy_disc_u = @(x)  min(maxu, max(minu, (hu* round(-K*x / hu))));

filename = ['plots/exact__minu_' num2str(minu) '_hu_' num2str(hu) '_maxu_' num2str(maxu)];

[qsim, usim, vpi] = simulate_policy(dynamics, policy_disc_u, cost, gamma, meshgrid_q0, meshgrid_qdot0, H);

plot_sim_trajectories_values(meshgrid_q0, meshgrid_qdot0, qsim, usim, vpi, filename);
end

hu = 0.2;  %fine enough that the action discretization isn't significantly affecting the solution

%% 2. let's discretize the state-action space / build an MDP

for dqqdot = [1 0.5 0.1] %starts doing worse for discretizations finer than 0.1, maybe something about boundary conditions...

dqqdot

minq = 2*q0(1); hq = dqqdot; maxq = 2*q0(end);
minqdot = 2*qdot0(1); hqdot = dqqdot; maxqdot = 2*qdot0(end);

[q,qdot] = meshgrid(minq:hq:maxq, minqdot:hqdot:maxqdot);

kk=size(q,1); ll=size(q,2);

nS = kk*ll;
nA = length(minu:hu:maxu);

%% 2a. nearest neighbor dynamics

    
clear mdp

for a = 1:nA
    mdp.T{a} = sparse(nS,nS);
    mdp.R{a} = sparse(nS,nS);
    u = a2u(a, minu, hu, maxu);
    for s=1:nS
        qqdot = s2qqdot(s, minq, hq, maxq, minqdot, hqdot, maxqdot);
        qqdotnext = A*qqdot + B*u;
        snext = qqdot2s(qqdotnext, minq, hq, maxq, minqdot, hqdot, maxqdot);
        mdp.T{a}(s,snext) = 1;
        mdp.R{a}(s,snext) = -0.5*qqdot'*Q*qqdot - 0.5*u'*R*u;
    end
end
mdp.gamma = gamma;

my_precision = 1;
max_iters = 100;
[mdp_sol.V, mdp_sol.pi, mdp_sol.Q] = value_iteration(mdp, my_precision, max_iters);

%let's execture the MDP's optimal policy in the actual dynamical system and
%plot results:

filename = ['plots/approximate__0order_MDP__0order_policy__minu_' num2str(minu) '_hu_' num2str(hu) '_maxu_' num2str(maxu) '__minq_' num2str(minq) '_maxq_' num2str(maxq) '_minqdot_' num2str(minqdot) '_maxqdot_' num2str(maxqdot) '_h_' num2str(hq)];
policy_mdp = @(x) a2u(  mdp_sol.pi(qqdot2s(x,minq,hq,maxq,minqdot,hqdot,maxqdot))  ,minu, hu, maxu);
[qsim, usim, vpi] = simulate_policy(dynamics, policy_mdp, cost, gamma, meshgrid_q0, meshgrid_qdot0, H);
plot_sim_trajectories_values(meshgrid_q0, meshgrid_qdot0, qsim, usim, vpi, filename);

filename = ['plots/approximate__0order_MDP__lookahead_policy__minu_' num2str(minu) '_hu_' num2str(hu) '_maxu_' num2str(maxu) '__minq_' num2str(minq) '_maxq_' num2str(maxq) '_minqdot_' num2str(minqdot) '_maxqdot_' num2str(maxqdot) '_h_' num2str(hq)];
discrete_bit = 1;
order = 0;
policy_mdp_lookahead_wrapper = @(x) policy_mdp_lookahead(order, discrete_bit, x, dynamics, cost, gamma, mdp_sol.V, minq, hq, maxq, minqdot, hqdot, maxqdot, minu, hu, maxu);
[qsim, usim, vpi] = simulate_policy(dynamics, policy_mdp_lookahead_wrapper, cost, gamma, meshgrid_q0, meshgrid_qdot0, H);
plot_sim_trajectories_values(meshgrid_q0, meshgrid_qdot0, qsim, usim, vpi, filename);


%% 2b. 1st order discretization

clear mdp

for a = 1:nA
    mdp.T{a} = sparse(nS,nS);
    mdp.R{a} = sparse(nS,nS);
    u = a2u(a, minu, hu, maxu);
    for s=1:nS
        qqdot = s2qqdot(s, minq, hq, maxq, minqdot, hqdot, maxqdot);
        qqdotnext = A*qqdot + B*u;
        [snext, w] = qqdot2s_1st_order(qqdotnext, minq, hq, maxq, minqdot, hqdot, maxqdot);
        for i=1:length(w)
            mdp.T{a}(s,snext(i)) = mdp.T{a}(s,snext(i)) + w(i); %add rather than "=" as there might be repeat states in snext
            mdp.R{a}(s,snext(i)) = -0.5*qqdot'*Q*qqdot - 0.5*u'*R*u;
        end
    end
end
mdp.gamma = gamma;

my_precision = 1;
max_iters = 100;
[mdp_sol.V, mdp_sol.pi, mdp_sol.Q] = value_iteration(mdp, my_precision, max_iters);

%let's execture the MDP's optimal policy in the actual dynamical system and
%plot results:

filename = ['plots/approximate__1order_MDP__nearest-neighbor-policy__minu_' num2str(minu) '_hu_' num2str(hu) '_maxu_' num2str(maxu) '__minq_' num2str(minq) '_maxq_' num2str(maxq) '_minqdot_' num2str(minqdot) '_maxqdot_' num2str(maxqdot) '_h_' num2str(hq)];
policy_mdp_nearest_neighbor = @(x) a2u(  mdp_sol.pi(qqdot2s(x,minq,hq,maxq,minqdot,hqdot,maxqdot))  ,minu, hu, maxu);
[qsim, usim, vpi] = simulate_policy(dynamics, policy_mdp_nearest_neighbor, cost, gamma, meshgrid_q0, meshgrid_qdot0, H);
plot_sim_trajectories_values(meshgrid_q0, meshgrid_qdot0, qsim, usim, vpi,filename);

filename = ['plots/approximate__1order_MDP__interpolate-nearest-neighbors-policy__minu_' num2str(minu) '_hu_' num2str(hu) '_maxu_' num2str(maxu) '__minq_' num2str(minq) '_maxq_' num2str(maxq) '_minqdot_' num2str(minqdot) '_maxqdot_' num2str(maxqdot) '_h_' num2str(hq)];
policy_mdp_interpolate_wrapper = @(x) policy_mdp_interpolate(mdp_sol.pi, x, minq,hq,maxq,minqdot,hqdot,maxqdot, minu, hu, maxu)
[qsim, usim, vpi] = simulate_policy(dynamics, policy_mdp_interpolate_wrapper, cost, gamma, meshgrid_q0, meshgrid_qdot0, H);
plot_sim_trajectories_values(meshgrid_q0, meshgrid_qdot0, qsim, usim, vpi,filename);


filename = ['plots/approximate__1order_MDP__lookahead-policy__minu_' num2str(minu) '_hu_' num2str(hu) '_maxu_' num2str(maxu) '__minq_' num2str(minq) '_maxq_' num2str(maxq) '_minqdot_' num2str(minqdot) '_maxqdot_' num2str(maxqdot) '_h_' num2str(hq)];
discrete_bit=1;
order = 1;
policy_mdp_lookahead_wrapper = @(x) policy_mdp_lookahead(order, discrete_bit, x, dynamics, cost, gamma, mdp_sol.V, minq, hq, maxq, minqdot, hqdot, maxqdot, minu, hu, maxu);
[qsim, usim, vpi] = simulate_policy(dynamics, policy_mdp_lookahead_wrapper, cost, gamma, meshgrid_q0, meshgrid_qdot0, H);
plot_sim_trajectories_values(meshgrid_q0, meshgrid_qdot0, qsim, usim, vpi,filename);

end





