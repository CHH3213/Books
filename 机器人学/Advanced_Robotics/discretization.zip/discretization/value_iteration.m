%% Copyright (C) 2015 — Pieter Abbeel — All rights reserved.
%% This code was developed for CS 287 Advanced Robotics.  
%% This code is free to be re-used for educational purposes as long as
%% this copyright notice is included.
%% For all other uses, please contact the author at pabbeel@cs.berkeley.edu.% value iteration:

function [V, pi] = value_iteration(mdp, precision)

%IN: mdp, precision
%OUT: V, pi

% Recall: to obtain an estimate of the value function within accuracy of
% "precision" it suffices that one of the following conditions is met:
%   (i)  max(abs(V_new-V)) <= precision / (2*gamma/(1-gamma))
%   (ii) gamma^i * Rmax / (1-gamma) <= precision  -- with i the value
%   iteration count, and Rmax = max_{s,a,s'} | R(s,a,s') |

%% This needs to be completed with code for value iteration; the
%% corresponding file from Problem Set 1 will do.