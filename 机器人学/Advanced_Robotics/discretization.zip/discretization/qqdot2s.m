%% Copyright (C) 2015 — Pieter Abbeel — All rights reserved.
%% This code was developed for CS 287 Advanced Robotics.  
%% This code is free to be re-used for educational purposes as long as
%% this copyright notice is included.
%% For all other uses, please contact the author at
%% pabbeel@cs.berkeley.edu.

function [ s ] = qqdot2s( qqdot, minq, hq, maxq, minqdot, hqdot, maxqdot )

% make sure we are in the box
qqdot(1) = min(maxq, max(minq, qqdot(1)));
qqdot(2) = min(maxqdot, max(minqdot, qqdot(2)));

sq = round( (qqdot(1) - minq) /hq ) + 1;
sqdot = round((qqdot(2) - minqdot) / hqdot) + 1;

nQ = round( (maxq-minq)/hq) + 1;

s = sq + (sqdot-1)*nQ;

end

