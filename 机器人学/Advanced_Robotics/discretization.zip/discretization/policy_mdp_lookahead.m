%% Copyright (C) 2015 — Pieter Abbeel — All rights reserved.
%% This code was developed for CS 287 Advanced Robotics.  
%% This code is free to be re-used for educational purposes as long as
%% this copyright notice is included.
%% For all other uses, please contact the author at
%% pabbeel@cs.berkeley.edu.

function [ u_opt ] = policy_mdp_lookahead(order, discrete_bit, x, dynamics, cost, gamma, V, minq, hq, maxq, minqdot, hqdot, maxqdot, minu, hu, maxu)

if(discrete_bit)
    u_options = minu:hu:maxu;
else
    u_options = minu:(hu/10):maxu; %ideally a continuous search in this case over all actions, but let's call this good enough for now
end

for k=1:length(u_options)
    u = u_options(k);
    xnext = dynamics(x,u);
    if(order == 0)
        Q(k) = - cost(x,u) + gamma*V(qqdot2s(xnext, minq, hq, maxq, minqdot, hqdot, maxqdot));
    elseif(order==1)
        [snext, w] = qqdot2s_1st_order(xnext, minq, hq, maxq, minqdot, hqdot, maxqdot);
        Q(k) = - cost(x,u);
        for i=1:length(w)
            Q(k) = Q(k) + gamma*w(i)*V(snext(i));
        end
    else
        'bug...'
    end
    [V_opt, a_opt] = max(Q);
    u_opt = u_options(a_opt);
    
end
