%% Copyright (C) 2015 — Pieter Abbeel — All rights reserved.
%% This code was developed for CS 287 Advanced Robotics.  
%% This code is free to be re-used for educational purposes as long as
%% this copyright notice is included.
%% For all other uses, please contact the author at
%% pabbeel@cs.berkeley.edu.

function [continuous_state] = smixed2qqdot_1st_order( s, w, minq, hq, maxq, minqdot, hqdot, maxqdot )

if(length(s)~=length(w))
    'ouch, bug'
end

for i=1:length(s)
    s_cont(:,i) = s2qqdot(s(i), minq, hq, maxq, minqdot, hqdot, maxqdot);
end

continuous_state = s_cont*w;

end

