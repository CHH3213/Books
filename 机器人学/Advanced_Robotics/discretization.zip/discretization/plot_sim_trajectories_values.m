%% Copyright (C) 2015 — Pieter Abbeel — All rights reserved.
%% This code was developed for CS 287 Advanced Robotics.  
%% This code is free to be re-used for educational purposes as long as
%% this copyright notice is included.
%% For all other uses, please contact the author at
%% pabbeel@cs.berkeley.edu.

function plot_sim_trajectories_values(meshgrid_q, meshgrid_qdot, qsim, usim, vpi, filename)

kk=length(qsim);
ll=length(qsim{1});

%let's plot the trajectories:
figure; hold on;
for k=1:1:kk
    for l=1:1:ll
        plot(qsim{k}{l}(1,:), qsim{k}{l}(2,:));
        plot(qsim{k}{l}(1,end), qsim{k}{l}(2,end),'go');
        plot(qsim{k}{l}(1,1), qsim{k}{l}(2,1),'rx');
    end
end

if(~isempty(filename))
    filename2 = [filename '__trajectories.png'];
    print('-dpng', [], filename2);
end


% %let's plot the controls:
% figure; hold on;
% for k=1:kk
%     for l=1:ll
%         plot(usim{k}{l});
%     end
% end



%let's plot the values:
figure; contourf(meshgrid_q, meshgrid_qdot,vpi); colorbar;


if(~isempty(filename))
    filename3 = [filename '__values.png'];
    print('-dpng', [], filename3);
end

