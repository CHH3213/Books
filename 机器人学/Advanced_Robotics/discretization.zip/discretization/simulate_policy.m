%% Copyright (C) 2015 — Pieter Abbeel — All rights reserved.
%% This code was developed for CS 287 Advanced Robotics.  
%% This code is free to be re-used for educational purposes as long as
%% this copyright notice is included.
%% For all other uses, please contact the author at
%% pabbeel@cs.berkeley.edu.

function [qsim, usim, vpi, q, qdot] = simulate_policy(dynamics, policy, cost, gamma, meshgrid_q0, meshgrid_qdot0, H);

kk=size(meshgrid_q0,1);
ll=size(meshgrid_q0,2);

vpi = zeros(kk,ll);
for k=1:kk
    for l=1:ll
        qsim{k}{l} = zeros(2,H);
        usim{k}{l} = zeros(1,H);
        qsim{k}{l}(:,1) = [meshgrid_q0(k,l); meshgrid_qdot0(k,l)];
        for t=1:H-1
            usim{k}{l}(:,t) = policy(qsim{k}{l}(:,t));
            qsim{k}{l}(:,t+1) = dynamics(qsim{k}{l}(:,t), usim{k}{l}(:,t));
            vpi(k,l) = vpi(k,l) + gamma^(t-1)*cost(qsim{k}{l}(:,t),usim{k}{l}(:,t));
        end
    end
end
