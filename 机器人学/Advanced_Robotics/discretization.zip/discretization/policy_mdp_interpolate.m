%% Copyright (C) 2015 — Pieter Abbeel — All rights reserved.
%% This code was developed for CS 287 Advanced Robotics.  
%% This code is free to be re-used for educational purposes as long as
%% this copyright notice is included.
%% For all other uses, please contact the author at
%% pabbeel@cs.berkeley.edu.

function [ u ] = policy_mdp_interpolate(pi, x, minq, hq, maxq, minqdot, hqdot, maxqdot, minu, hu, maxu)

[s,w] = qqdot2s_1st_order(x, minq,hq,maxq,minqdot,hqdot,maxqdot);

for i=1:length(s)
    action(i,1) = a2u(  pi(qqdot2s(x,minq,hq,maxq,minqdot,hqdot,maxqdot)) , minu, hu, maxu);
end

u = action'*w;

end

