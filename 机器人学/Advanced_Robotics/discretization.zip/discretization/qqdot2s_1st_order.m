%% Copyright (C) 2015 — Pieter Abbeel — All rights reserved.
%% This code was developed for CS 287 Advanced Robotics.  
%% This code is free to be re-used for educational purposes as long as
%% this copyright notice is included.
%% For all other uses, please contact the author at
%% pabbeel@cs.berkeley.edu.

function [ discrete_states, weights ] = qqdot2s_1st_order(qqdot, minq, hq, maxq, minqdot, hqdot, maxqdot)

% find the surrounding 4 states;

% make sure we are in the box
qqdot(1) = min(maxq, max(minq, qqdot(1)));
qqdot(2) = min(maxqdot, max(minqdot, qqdot(2)));

sq0 = floor( (qqdot(1) - minq) /hq ) + 1;
sq1 = ceil( (qqdot(1) - minq) /hq ) + 1;

alpha = (qqdot(1) - ( (sq0-1) *hq + minq))/hq;

if(alpha < 0.001)
    alpha = 0; %let's keep things sparse
elseif (alpha > 0.999)
    alpha = 1;
end




sqdot0 = floor((qqdot(2) - minqdot) / hqdot) + 1;
sqdot1 = ceil((qqdot(2) - minqdot) / hqdot) + 1;

beta = (qqdot(2) - ((sqdot0-1)*hqdot + minqdot)) / hqdot;

if(beta < 0.001)
    beta = 0; % let's keep things sparse
elseif (beta > 0.999)
    beta = 1;
end


nQ = round( (maxq-minq)/hq) + 1;

s00 = sq0 + (sqdot0-1)*nQ;
s01 = sq0 + (sqdot1-1)*nQ;
s10 = sq1 + (sqdot0-1)*nQ;
s11 = sq1 + (sqdot1-1)*nQ;

discrete_states = [s00; s01; s10; s11];

weights = [(1-alpha)*(1-beta); (1-alpha)*beta; alpha*(1-beta); alpha*beta];

end


