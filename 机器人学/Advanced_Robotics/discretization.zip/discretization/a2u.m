function [ u ] = a2u(a, minU, hu, maxU)

u = minU + (a-1)*hu;

end

