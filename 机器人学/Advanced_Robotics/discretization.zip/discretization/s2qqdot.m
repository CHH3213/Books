%% Copyright (C) 2015 — Pieter Abbeel — All rights reserved.
%% This code was developed for CS 287 Advanced Robotics.  
%% This code is free to be re-used for educational purposes as long as
%% this copyright notice is included.
%% For all other uses, please contact the author at
%% pabbeel@cs.berkeley.edu.

function [ qqdot ] = s2qqdot(s, minq, hq, maxq, minqdot, hqdot, maxqdot )

% s = sq + (sqdot-1) * nQ

nQ = round( (maxq-minq)/hq) + 1;
nQdot = round( (maxqdot-minqdot)/hqdot) + 1;

if (s < 1)
    'warning, s<1'
elseif (s > nQ*nQdot)
    'warning, s> nQ*nQdot'
end


sqdot = floor( (s-1) / nQ)  + 1;
sq = s - (sqdot-1)*nQ;

qqdot = [minq+ (sq-1)*hq; minqdot + (sqdot-1)*hqdot];

end

